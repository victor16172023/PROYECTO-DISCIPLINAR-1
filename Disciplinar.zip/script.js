
// JavaScript placeholder
console.log("JS is loaded!");
